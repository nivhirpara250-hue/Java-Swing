import javax.swing.*;
import java.awt.*;

class swing_basic_1
{
	public static void main(String args[])
	{
		JFrame f=new JFrame();
		
		f.setSize(500,500);
		f.setLayout(null);
		f.setVisible(true);
		
	}
}